# libraryshare/tests.py
from django.test import TestCase
from .models import Story

class StoryModelTest(TestCase):

    def setUp(self):
        Story.objects.create(title="Test Story", content="This is a test content")

    def test_story_content(self):
        story = Story.objects.get(title="Test Story")
        self.assertEqual(story.content, "This is a test content")